// A6: 8-Queens with the FIRST queen's position given (Backtracking)
// pos[row] = column of the queen in that row (-1 = no queen yet).
// The first queen is fixed; backtracking places queens in the other rows.
// Sample: first queen at row 1, column 1
#include <iostream>
#include <cstdlib>
using namespace std;

const int N = 8;
int pos[N];

// A queen at (row, col) is safe if no other queen shares its column or diagonal
bool isSafe(int row, int col) {
    for (int i = 0; i < N; i++) {
        if (pos[i] == -1 || i == row) continue;
        if (pos[i] == col) return false;                         // same column
        if (abs(pos[i] - col) == abs(i - row)) return false;     // same diagonal
    }
    return true;
}

bool solve(int row, int fixedRow) {
    if (row == N) return true;                    // all rows done
    if (row == fixedRow) return solve(row + 1, fixedRow);   // skip the fixed queen's row

    for (int col = 0; col < N; col++) {
        if (isSafe(row, col)) {
            pos[row] = col;                       // place
            if (solve(row + 1, fixedRow)) return true;
            pos[row] = -1;                        // backtrack
        }
    }
    return false;
}

int main() {
    int r, c;
    cout << "Enter row and column (1-8) of the first queen: ";
    cin >> r >> c;
    r--; c--;

    for (int i = 0; i < N; i++) pos[i] = -1;
    pos[r] = c;

    if (solve(0, r)) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) cout << (pos[i] == j ? " Q" : " .");
            cout << endl;
        }
    } else {
        cout << "No solution with the first queen at that position\n";
    }
    return 0;
}
