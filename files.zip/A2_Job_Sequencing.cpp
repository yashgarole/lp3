// A2: Job Sequencing with Deadlines (Greedy)
// Idea: sort jobs by profit (high -> low). Put each job in the LATEST free slot
// on or before its deadline. If no slot is free, skip the job.
// Sample input:  4 jobs ->  a 4 20 | b 1 10 | c 1 40 | d 1 30   => order c a, profit 60
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

struct Job {
    char id;
    int deadline;
    int profit;
};

bool cmp(Job x, Job y) { return x.profit > y.profit; }   // higher profit first

int main() {
    int n;
    cout << "Enter number of jobs: ";
    cin >> n;
    vector<Job> jobs(n);
    cout << "Enter job id, deadline, profit:\n";
    for (int i = 0; i < n; i++) cin >> jobs[i].id >> jobs[i].deadline >> jobs[i].profit;

    sort(jobs.begin(), jobs.end(), cmp);                  // Step 1: sort by profit

    int maxD = 0;
    for (int i = 0; i < n; i++) maxD = max(maxD, jobs[i].deadline);

    vector<char> slot(maxD + 1, '-');                     // slot[t] = job done at time t
    int totalProfit = 0;

    for (int i = 0; i < n; i++) {                         // Step 2: place each job
        for (int t = jobs[i].deadline; t >= 1; t--) {
            if (t <= maxD && slot[t] == '-') {
                slot[t] = jobs[i].id;
                totalProfit += jobs[i].profit;
                break;
            }
        }
    }

    cout << "Job sequence: ";
    for (int t = 1; t <= maxD; t++)
        if (slot[t] != '-') cout << slot[t] << " ";
    cout << "\nTotal profit = " << totalProfit << endl;
    return 0;
}
