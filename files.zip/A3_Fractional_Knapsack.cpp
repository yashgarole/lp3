// A3: Fractional Knapsack (Greedy)
// Idea: sort items by value/weight ratio (high -> low). Take whole items while they
// fit; for the last item take only the fraction that fits.
// Sample: weights 10 20 30, values 60 100 120, W = 50  => answer 240
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

struct Item {
    int id;
    double weight, value, ratio;
};

bool cmp(Item a, Item b) { return a.ratio > b.ratio; }    // best ratio first

int main() {
    int n;
    double W;
    cout << "Enter number of items: ";
    cin >> n;
    vector<Item> items(n);
    cout << "Enter weight and value of each item:\n";
    for (int i = 0; i < n; i++) {
        items[i].id = i + 1;
        cin >> items[i].weight >> items[i].value;
        items[i].ratio = items[i].value / items[i].weight;
    }
    cout << "Enter knapsack capacity: ";
    cin >> W;

    sort(items.begin(), items.end(), cmp);

    double totalValue = 0;
    for (int i = 0; i < n && W > 0; i++) {
        if (items[i].weight <= W) {                       // take the whole item
            W -= items[i].weight;
            totalValue += items[i].value;
            cout << "Item " << items[i].id << " taken fully\n";
        } else {                                          // take only a fraction
            double frac = W / items[i].weight;
            totalValue += items[i].value * frac;
            cout << "Item " << items[i].id << " taken " << frac * 100 << "%\n";
            W = 0;
        }
    }
    cout << "Maximum value = " << totalValue << endl;
    return 0;
}
