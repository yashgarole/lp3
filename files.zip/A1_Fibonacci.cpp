// A1: Fibonacci numbers and number of computational steps
// Iterative  -> O(n)      Recursive -> O(2^n)
#include <iostream>
using namespace std;

int recSteps = 0;                 // counts every recursive call

int fibRec(int n) {
    recSteps++;                   // 1 step per call
    if (n <= 1) return n;         // base case
    return fibRec(n - 1) + fibRec(n - 2);
}

int main() {
    int n;
    cout << "Enter number of terms: ";
    cin >> n;

    // ---------- Iterative ----------
    int a = 0, b = 1, steps = 0;
    cout << "Iterative series: ";
    for (int i = 0; i < n; i++) {
        cout << a << " ";
        int next = a + b;
        a = b;
        b = next;
        steps++;                  // 1 step per loop iteration
    }
    cout << "\nSteps (iterative) = " << steps << "   -> O(n)\n";

    // ---------- Recursive ----------
    cout << "Recursive series: ";
    for (int i = 0; i < n; i++) cout << fibRec(i) << " ";

    recSteps = 0;                 // reset, then count steps for the last term only
    fibRec(n - 1);
    cout << "\nSteps (recursive) to find term " << n << " = " << recSteps
         << "   -> O(2^n)\n";
    return 0;
}
