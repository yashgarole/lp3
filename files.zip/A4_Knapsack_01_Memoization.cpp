// A4: 0-1 Knapsack using Dynamic Programming - MEMOIZATION (top-down)
// knap(i, w) = best value using the first i items with capacity w
//   if wt[i] > w : knap(i-1, w)                         (cannot take item i)
//   else         : max( knap(i-1, w),                   (skip item i)
//                       val[i] + knap(i-1, w - wt[i]) ) (take item i)
// memo[i][w] stores answers already computed, so each state is solved only once.
// Sample: wt = 1 3 4 5, val = 1 4 5 7, W = 7  => answer 9
#include <iostream>
#include <cstring>
using namespace std;

int wt[100], val[100];
int memo[101][1001];

int knap(int i, int w) {
    if (i == 0 || w == 0) return 0;               // base case
    if (memo[i][w] != -1) return memo[i][w];      // already solved

    if (wt[i] > w)
        memo[i][w] = knap(i - 1, w);
    else
        memo[i][w] = max(knap(i - 1, w), val[i] + knap(i - 1, w - wt[i]));
    return memo[i][w];
}

int main() {
    int n, W;
    cout << "Enter number of items: ";
    cin >> n;
    cout << "Enter weight and value of each item:\n";
    for (int i = 1; i <= n; i++) cin >> wt[i] >> val[i];
    cout << "Enter knapsack capacity: ";
    cin >> W;

    memset(memo, -1, sizeof(memo));               // -1 = not computed yet
    cout << "Maximum value = " << knap(n, W) << endl;

    // Find which items were chosen
    cout << "Items selected: ";
    int w = W;
    for (int i = n; i >= 1; i--) {
        if (knap(i, w) != knap(i - 1, w)) {          // value changed => item i was taken
            cout << i << " ";
            w -= wt[i];
        }
    }
    cout << endl;
    return 0;
}
