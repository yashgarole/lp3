// A5: Binomial Coefficient using Dynamic Programming - MEMOIZATION (top-down)
// C(n,k) = C(n-1,k-1) + C(n-1,k)      C(n,0) = C(n,n) = 1
// memo[n][k] saves each answer so it is calculated only once.  Time O(n*k)
// Sample: n = 5, k = 2  => 10
#include <iostream>
#include <cstring>
using namespace std;

long long memo[101][101];

long long C(int n, int k) {
    if (k == 0 || k == n) return 1;               // base case
    if (memo[n][k] != -1) return memo[n][k];      // already solved
    memo[n][k] = C(n - 1, k - 1) + C(n - 1, k);
    return memo[n][k];
}

int main() {
    int n, k;
    cout << "Enter n and k: ";
    cin >> n >> k;
    if (k > n) {
        cout << "k must be <= n\n";
        return 0;
    }
    memset(memo, -1, sizeof(memo));
    cout << "C(" << n << "," << k << ") = " << C(n, k) << endl;
    return 0;
}
